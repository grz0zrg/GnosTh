# language-forth

Adds syntax highlighting to Gforth files in VSCode. Note will work for most Forth files. 

This package was forked from [language-forth](https://github.com/harrypower/language-forth). I added highlighting for the .f files and autoclosing support for `."` and `:`.

## Features

- Syntax highlighting

    ![Screenshoot](https://github.com/fttx/language-forth/raw/master/images/screenshoot.png)

## Release Notes

Add file extension detection
